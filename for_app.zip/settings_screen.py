# from turtle import _Color

from kivy.app import App

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.slider import Slider
from kivy.uix.button import Button
from kivy.uix.switch import Switch

from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.togglebutton import ToggleButton


class SettingsScreen(BoxLayout):

    def __init__(self, settings, tts, **kwargs):

        super().__init__(
            orientation="vertical",
            padding=20,
            spacing=15,
            **kwargs
        )
        with self.canvas.before:
            Color(
                0.97, 0.98, 1.0, 1
            )

            self.bg = RoundedRectangle(
                pos=self.pos,
                size=self.size
            )

        self.bind(
            pos=lambda instance, value:
            setattr(self.bg, "pos", value)
        )

        self.bind(
            size=lambda instance, value:
            setattr(self.bg, "size", value)
        )

        self.settings = settings
        self.tts = tts

        # =============================================
        # TITLE
        # =============================================

        self.add_widget(
            Label(
                text="VISIONAID SETTINGS",
                font_size=26,
                bold=True,
                color=(0.08, 0.25, 0.40, 1),
                size_hint=(1, 0.12)
            )
        )

        # =============================================
        # SPEECH VOLUME
        # =============================================

        self.add_widget(
            Label(
                text="Speech Volume",
                font_size=17,
                bold=True,
                color=(0.08, 0.25, 0.40, 1)
            )
        )

        volume_layout = BoxLayout(
            orientation="horizontal",
            size_hint=(1, 0.12)
        )

        self.volume_value = Label(
            text=str(self.settings.volume),
            size_hint=(0.2, 1),
            color=(0.08, 0.25, 0.40, 1),
            bold=True
        )

        self.volume_slider = Slider(
            min=0,
            max=100,
            value=self.settings.volume
        )

        self.volume_slider.bind(
            value=self.change_volume
        )

        volume_layout.add_widget(
            self.volume_slider
        )

        volume_layout.add_widget(
            self.volume_value
        )

        self.add_widget(volume_layout)

        # =============================================
        # SPEECH SPEED
        # =============================================

        self.add_widget(
            Label(
                text="Speech Speed",
                font_size=17,
                bold=True,
                color=(0.08, 0.25, 0.40, 1)
                )
        )

        speed_layout = BoxLayout(
            orientation="horizontal",
            size_hint=(1, 0.12)
        )

        self.speed_value = Label(
            text=str(self.settings.rate),
            size_hint=(0.2, 1),
            color=(0.08, 0.25, 0.40, 1),
            bold=True
        )

        self.speed_slider = Slider(
            min=-10,
            max=10,
            value=self.settings.rate
        )

        self.speed_slider.bind(
            value=self.change_speed
        )

        speed_layout.add_widget(
            self.speed_slider
        )

        speed_layout.add_widget(
            self.speed_value
        )

        self.add_widget(speed_layout)

        # =============================================
        # OBSTACLE SENSITIVITY
        # =============================================

        self.add_widget(
            Label(
                text="Obstacle Sensitivity",
                font_size=17,
                bold=True,
                color=(0.08, 0.25, 0.40, 1)
            )
        )

        obstacle_layout = BoxLayout(
            orientation="horizontal",
            size_hint=(1, 0.12)
        )

        self.obstacle_value = Label(
            text=str(
                self.settings.obstacle_threshold
            ),
            size_hint=(0.2, 1),
            color=(0.08, 0.25, 0.40, 1),
            bold=True
        )

        self.obstacle_slider = Slider(
            min=0.10,
            max=0.50,
            value=self.settings.obstacle_threshold
        )

        self.obstacle_slider.bind(
            value=self.change_obstacle
        )

        obstacle_layout.add_widget(
            self.obstacle_slider
        )

        obstacle_layout.add_widget(
            self.obstacle_value
        )

        self.add_widget(obstacle_layout)

        # =============================================
        # VOICE COMMANDS
        # =============================================

        voice_layout = BoxLayout(
            orientation="horizontal",
            size_hint=(1, 0.12),
            spacing=10
        )

        voice_label = Label(
            text="Voice Commands",
            font_size=17,
            bold=True,
            color=(0.08, 0.25, 0.40, 1)
        )

        # self.voice_status = Label(
        #     text="ON" if self.settings.voice_enabled else "OFF",
        #     font_size=15,
        #     bold=True,
        #     size_hint=(0.20, 1),
        #     color=(0.08, 0.25, 0.40, 1)
        # )

        # self.voice_switch = Switch(
        #     active=self.settings.voice_enabled
        # )

        # self.voice_switch.bind(
        #     active=self.change_voice
        # )
        self.voice_switch = ToggleButton(
            text="ON" if self.settings.voice_enabled else "OFF",
            state="down" if self.settings.voice_enabled else "normal",
            font_size=15,
            bold=True,
            size_hint=(0.28, 0.8),
            background_normal="",
            background_down="",
            background_color=(0, 0, 0, 0),
            color=(0.08, 0.22, 0.35, 1)
        )

        with self.voice_switch.canvas.before:

            Color(
                0.72, 0.84, 0.95, 1
            )

            self.voice_switch.bg = RoundedRectangle(
                pos=self.voice_switch.pos,
                size=self.voice_switch.size,
                radius=[dp(15)]
            )

        self.voice_switch.bind(
            pos=lambda instance, value:
            setattr(instance.bg, "pos", value)
        )

        self.voice_switch.bind(
            size=lambda instance, value:
            setattr(instance.bg, "size", value)
        )

        self.voice_switch.bind(
            state=self.change_voice
    )

        voice_layout.add_widget(
            voice_label
        )

        voice_layout.add_widget(
            self.voice_switch
        )

        # voice_layout.add_widget(
        #     self.voice_status
        # )

        self.add_widget(
            voice_layout
        )

        # =============================================
        # TEST VOICE BUTTON
        # =============================================

        test_voice_button = Button(
            text="TEST VOICE",
            font_size=16,
            bold=True,
            size_hint=(1, 0.10),
            background_normal="",
            background_down="",
            background_color=(0, 0, 0, 0),
            color=(0.08, 0.22, 0.35, 1)
        )

        with test_voice_button.canvas.before:

            Color(
                0.72, 0.84, 0.95, 1
            )

            test_voice_button.bg = RoundedRectangle(
                pos=test_voice_button.pos,
                size=test_voice_button.size,
                radius=[dp(16)]
            )

        test_voice_button.bind(
            pos=lambda instance, value:
            setattr(instance.bg, "pos", value)
        )

        test_voice_button.bind(
            size=lambda instance, value:
            setattr(instance.bg, "size", value)
        )

        test_voice_button.bind(
            on_press=self.test_voice
        )

        self.add_widget(test_voice_button)

        # =============================================
        # CLOSE BUTTON
        # =============================================

        close_button = Button(
            text="BACK",
            font_size=18,
            bold=True,
            size_hint=(1, 0.12),
            background_normal="",
            background_down="",
            background_color=(0, 0, 0, 0),
            color=(0.08, 0.22, 0.35, 1)
        )

        with close_button.canvas.before:
            Color(
                0.72, 0.84, 0.95, 1
            )

            close_button.bg = RoundedRectangle(
                pos=close_button.pos,
                size=close_button.size,
                radius=[dp(16)]
            )

        close_button.bind(
        pos=lambda instance, value:
        setattr(instance.bg, "pos", value)
        )

        close_button.bind(
        size=lambda instance, value:
        setattr(instance.bg, "size", value)
        )

        close_button.bind(
        on_press=self.close_settings
        )

        self.add_widget(close_button)

    # =============================================
    # VOLUME
    # =============================================

    def change_volume(
        self,
        instance,
        value
    ):

        value = int(value)

        self.settings.set_volume(
            value
        )

        self.tts.set_volume(
            value
        )

        self.volume_value.text = str(
            value
        )

    # =============================================
    # SPEED
    # =============================================

    def change_speed(
        self,
        instance,
        value
    ):

        value = int(value)

        self.settings.set_rate(
            value
        )

        self.tts.set_rate(
            value
        )

        self.speed_value.text = str(
            value
        )

    # =============================================
    # OBSTACLE
    # =============================================

    def change_obstacle(
        self,
        instance,
        value
    ):

        value = round(
            float(value),
            2
        )

        self.settings.set_obstacle_threshold(
            value
        )

        self.obstacle_value.text = str(
            value
        )

    # =============================================
    # VOICE
    # =============================================

    def change_voice(
            self,
            instance,
            value
        ):

        enabled = value == "down"

        self.settings.set_voice_enabled(
            enabled
        )

        self.voice_switch.text = (
            "ON" if enabled else "OFF"
        )

    # =============================================
    # TEST VOICE
    # =============================================

    def test_voice(self, instance):

        self.tts.speak(
            "VisionAid voice settings are working"
        )

    # =============================================
    # CLOSE
    # =============================================

    def close_settings(self, instance):

        parent = self.parent

        if parent:

            parent.remove_widget(
                self
            )