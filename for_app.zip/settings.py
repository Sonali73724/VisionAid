class VisionSettings:

    def __init__(self):

        # Speech
        self.volume = 100
        self.rate = 0

        # Obstacle sensitivity
        self.obstacle_threshold = 0.25

        # Voice command
        self.voice_enabled = True


    # ================================================
    # SPEECH VOLUME
    # ================================================

    def set_volume(self, value):

        value = int(value)

        value = max(
            0,
            min(100, value)
        )

        self.volume = value


    # ================================================
    # SPEECH RATE
    # ================================================

    def set_rate(self, value):

        value = int(value)

        value = max(
            -10,
            min(10, value)
        )

        self.rate = value


    # ================================================
    # OBSTACLE SENSITIVITY
    # ================================================

    def set_obstacle_threshold(self, value):

        value = float(value)

        value = max(
            0.10,
            min(0.50, value)
        )

        self.obstacle_threshold = value


    # ================================================
    # VOICE COMMAND
    # ================================================

    def set_voice_enabled(self, enabled):

        self.voice_enabled = bool(enabled)