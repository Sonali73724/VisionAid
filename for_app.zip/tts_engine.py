import platform
import threading


class TTSEngine:

    def __init__(self):

        self.system = platform.system()

        self.speaker = None

        if self.system == "Windows":

            try:

                import win32com.client

                self.speaker = win32com.client.Dispatch(
                    "SAPI.SpVoice"
                )

                self.speaker.Rate = 0
                self.speaker.Volume = 100

                print("✅ Windows SAPI TTS ready")

            except Exception as e:

                print("❌ SAPI initialization error:", e)


    def speak(self, text):

        if not text:
            return

        print("🔊", text)

        # Windows SAPI ko main thread mein call karo
        if self.system == "Windows":

            try:

                if self.speaker:

                    self.speaker.Speak(text)

            except Exception as e:

                print("❌ SAPI Error:", e)


        # Android
        elif self.system == "Android":

            try:

                from plyer import tts

                tts.speak(text)

            except Exception as e:

                print("❌ Android TTS Error:", e)


        else:

            print(
                "TTS not configured for:",
                self.system
            )


    def set_volume(self, volume):
        if self.system == "Windows" and self.speaker:
            self.speaker.Volume = int(volume)


    def set_rate(self, rate):
        if self.system == "Windows" and self.speaker:
            self.speaker.Rate = int(rate)
# =====================================================
# TEST
# =====================================================

if __name__ == "__main__":

    tts = TTSEngine()

    tts.speak(
        "VisionAid text to speech is working"
    )

    print("✅ TTS test completed")